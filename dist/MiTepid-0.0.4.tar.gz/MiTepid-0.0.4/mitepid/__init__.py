"""MiTepid - python-based Tool to simulate an epidemilogical model for the spread of COVID-19. """

__version__ = '0.0.1'
__author__ = 'Vahid Samadi Bokharaie <vahid.bokharaie@tuebingen.mpg.de>'
__all__ = [] 

